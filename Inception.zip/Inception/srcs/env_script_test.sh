export domain_name=jklocker.42.fr

export db_name=mydb
export db_user=jakob
export db_pass=12345678

export wp_admin=jakob
export wp_adminpass=12345678
export wp_adminmail=jakobklocker@hotmail.com

export wp_user=test
export wp_email=test@test.com
export wp_pass=12345678
