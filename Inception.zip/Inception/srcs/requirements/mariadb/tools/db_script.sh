# Start mysql service
service mysql start 

#Write everything into a tmp file, to write it into mysql than
#echo "CREATE DATABASE IF NOT EXISTS $db_name;"  >tmp.sql
#echo "CREATE USER IF NOT EXISTS '$db_user'@'%' IDENTIFIED BY '$db_pass' ;" >>tmp.sql
#echo "GRANT ALL PRIVILEGES ON $db_name.* TO '$db_user'@'%';" >>tmp.sql
#echo "ALTER USER 'root'@'localhost' IDENTIFIED BY '$db_pass';" >>tmp.sql
#echo "FLUSH PRIVILEGES;" >>tmp.sql

sudo usermod -d /var/lib/mysql/ mysql
echo "CREATE DATABASE IF NOT EXISTS $db_name;"  >tmp.sql
echo "CREATE USER IF NOT EXISTS '$db_user'@'%' IDENTIFIED BY '$db_pass' ;" >>tmp.sql
echo "GRANT ALL PRIVILEGES ON test.* TO '$db_user'@'%';" >>tmp.sql
echo "ALTER USER 'root'@'localhost' IDENTIFIED BY '$db_pass';" >>tmp.sql
echo "FLUSH PRIVILEGES;" >>tmp.sql


#write into mysql
mysql < tmp.sql

#kill/close mysql to run mysqld
kill $(cat /var/run/mysqld/mysqld.pid)

mysqld
